import { notFound } from "next/navigation"

export default function Home() {
  notFound()
}

